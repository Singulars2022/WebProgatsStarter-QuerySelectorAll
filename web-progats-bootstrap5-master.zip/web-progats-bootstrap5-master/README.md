# Maquetación de Web Progats usando Bootstrap 5

Maqueeta la Web de Progats usando Bootstrap 5.
Cambia la estructura HTML si lo consideras necesario.
[Vídeo](https://oscarm.tinytake.com/tt/NDkwNjE5MV8xNTQ2NjU2MA) explicando algunos dealles del diseño.
